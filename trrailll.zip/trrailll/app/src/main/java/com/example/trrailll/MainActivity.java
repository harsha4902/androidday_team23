package com.example.trrailll;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.content.Context;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 100;
    private RadioGroup locationRadioGroup;
    private RadioButton enableLocationRadioButton;
    private RadioButton enterLocationRadioButton;
    private EditText locationEditText;
    private EditText reasonEditText;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationRadioGroup = findViewById(R.id.locationRadioGroup);
        enableLocationRadioButton = findViewById(R.id.enableLocationRadioButton);
        enterLocationRadioButton = findViewById(R.id.enterLocationRadioButton);
        locationEditText = findViewById(R.id.locationEditText);
        reasonEditText = findViewById(R.id.reasonEditText);
        submitButton = findViewById(R.id.submitButton);

        enableLocationRadioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                locationEditText.setEnabled(false);
                locationEditText.setText("");
            }
        });

        enterLocationRadioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                locationEditText.setEnabled(true);
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (enableLocationRadioButton.isChecked()) {
                    if (checkLocationPermission()) {
                        getCurrentLocation();
                    } else {
                        requestLocationPermission();
                    }
                } else if (enterLocationRadioButton.isChecked()) {
                    String areaName = locationEditText.getText().toString().trim();
                    searchHospitals(areaName);
                }
            }
        });
    }

    private boolean checkLocationPermission() {
        int resultFine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        int resultCoarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        return resultFine == PackageManager.PERMISSION_GRANTED && resultCoarse == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            } else {
                Toast.makeText(this, "Location permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void getCurrentLocation() {
        // Check if location services are enabled
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager != null && !locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            // Location services are not enabled, show a dialog to enable them
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Location Services Required");
            builder.setMessage("Please enable location services to proceed.");
            builder.setPositiveButton("Enable", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // Open the location settings screen
                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    startActivity(intent);
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        } else {
            // Location services are enabled, proceed to get the current location
            FusedLocationProviderClient fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
            try {
                if (checkLocationPermission()) {
                    fusedLocationProviderClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if (location != null) {
                                Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
                                try {
                                    List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                                    if (addresses.size() > 0) {
                                        String areaName = addresses.get(0).getLocality();
                                        searchHospitals(areaName);
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                Toast.makeText(MainActivity.this, "Failed to get location.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } else {
                    requestLocationPermission();
                }
            } catch (SecurityException e) {
                e.printStackTrace();
            }
        }
    }



    private void searchHospitals(String areaName) {
        // Read the CSV file from the res/raw directory
        InputStream inputStream = getResources().openRawResource(R.raw.hospitalsfinal);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String line;
        List<String> hospitals = new ArrayList<>();
        try {
            while ((line = reader.readLine()) != null) {
                // Split each line of the CSV file by comma
                String[] parts = line.split(",");
                // Check if the area name matches the desired location
                if (parts.length > 1 && parts[1].equalsIgnoreCase(areaName)) {
                    hospitals.add(parts[0]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Process the list of hospitals
        if (!hospitals.isEmpty()) {
            // Display the list of hospitals or perform any other necessary actions
            StringBuilder sb = new StringBuilder();
            for (String hospital : hospitals) {
                sb.append(hospital).append("\n");
            }
            Toast.makeText(this, "Hospitals in the area:\n" + sb.toString(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "No hospitals found in the area.", Toast.LENGTH_SHORT).show();
        }
    }
}
